export const LOGO_URL =
	"https://www.pngarts.com/files/7/Food-Delivery-PNG-Transparent-Image.png";
export const MENU_API =
	"https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=23.19088557012942&lng=79.90561876482693&restaurantId=";
